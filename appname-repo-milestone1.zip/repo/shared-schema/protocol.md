# Wire Protocol — v1 (Milestone 1 scope)

Transport: WebSocket, `ws://<host-ip>:<port>/ws`. Default port `7890`.

All messages are JSON objects with a `type` field. Extra/unknown fields must be ignored by both sides (forward compatibility).

## Auth

After WebSocket handshake, the client's very first message must be `auth`. Server closes the connection if auth fails or if any other message type arrives first.

```json
// Client -> Server (first message, always)
{ "type": "auth", "pin": "483920" }
```

```json
// Server -> Client
{ "type": "auth_ok", "token": "a1b2c3d4-...", "hostName": "DESKTOP-ABC123" }
```

```json
// Server -> Client (auth failed)
{ "type": "auth_failed", "reason": "invalid_pin" }
```

Reconnects after the first pairing should send the saved `token` instead of the PIN:

```json
{ "type": "auth", "token": "a1b2c3d4-..." }
```

## Profile Sync

Server is authoritative. Sent automatically right after successful auth, and again any time the profile changes.

```json
{
  "type": "profile_sync",
  "profile": {
    "profileId": "p_default",
    "name": "Default",
    "buttons": [
      {
        "buttonId": "b_001",
        "position": { "row": 0, "col": 0 },
        "label": "Mute",
        "icon": null,
        "action": { "type": "hotkey", "keys": ["VolumeMute"] }
      },
      {
        "buttonId": "b_002",
        "position": { "row": 0, "col": 1 },
        "label": "Notepad",
        "icon": null,
        "action": { "type": "launch_app", "path": "notepad.exe" }
      }
    ]
  }
}
```

## Button Press

```json
// Client -> Server
{ "type": "button_press", "buttonId": "b_001", "pressType": "short" }
```

```json
// Server -> Client (ack)
{ "type": "ack", "buttonId": "b_001", "status": "ok" }
```

`status` can be `"ok"` or `"error"`; on error include a `"message"` field.

## Action Types (Milestone 1 subset)

| type | fields | behavior |
|---|---|---|
| `hotkey` | `keys: string[]` | Simulates the key combo via `SendInput` |
| `launch_app` | `path: string` | Starts the process |

More action types (`media_control`, `open_url`, `run_command`, `text_snippet`, `multi_action`) are defined in the full architecture spec and land in Milestone 2.

## Not Yet Implemented (future milestones)

- `profile_edit` (bidirectional editing) — Milestone 2
- Asset upload endpoint for custom icons — Milestone 3
- Folders / nested pages — Milestone 2
- mDNS discovery broadcast — Milestone 2 (manual IP entry works now)
