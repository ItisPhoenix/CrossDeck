using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using HostApp.Actions;
using HostApp.ProfileStore;

namespace HostApp.Server;

/// <summary>
/// Deliberately built on raw TcpListener + a manual WebSocket handshake instead of
/// System.Net.HttpListener. HttpListener requires either Administrator privileges or a
/// `netsh http add urlacl` reservation for any prefix other than exactly "http://localhost/",
/// which is a dealbreaker for a consumer app users just double-click to run. TcpListener has
/// no such restriction, so we do the HTTP Upgrade handshake by hand and then wrap the raw
/// stream with WebSocket.CreateFromStream.
/// </summary>
public class WebSocketServer
{
    private const string WebSocketMagicGuid = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    private readonly int _port;
    private readonly PairingManager _pairing;
    private readonly ProfileStoreService _profileStore;
    private readonly ActionExecutor _actionExecutor;

    private TcpListener? _listener;
    private CancellationTokenSource? _cts;

    public int Port => _port;
    public string LocalIpAddress { get; private set; } = "unknown";

    public WebSocketServer(int port, PairingManager pairing, ProfileStoreService profileStore, ActionExecutor actionExecutor)
    {
        _port = port;
        _pairing = pairing;
        _profileStore = profileStore;
        _actionExecutor = actionExecutor;
        LocalIpAddress = DetectLocalIpAddress();
    }

    public void Start()
    {
        _cts = new CancellationTokenSource();
        _listener = new TcpListener(IPAddress.Any, _port);
        _listener.Start();
        _ = AcceptLoopAsync(_cts.Token);
    }

    public void Stop()
    {
        _cts?.Cancel();
        _listener?.Stop();
    }

    private async Task AcceptLoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            TcpClient client;
            try
            {
                client = await _listener!.AcceptTcpClientAsync(ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (ObjectDisposedException)
            {
                break;
            }

            _ = HandleClientAsync(client, ct);
        }
    }

    private async Task HandleClientAsync(TcpClient tcpClient, CancellationToken ct)
    {
        using var _ = tcpClient;
        var stream = tcpClient.GetStream();

        WebSocket webSocket;
        try
        {
            webSocket = await PerformHandshakeAsync(stream, ct);
        }
        catch
        {
            return; // Not a valid WS handshake request — drop the connection.
        }

        string? authedToken = null;

        try
        {
            // First message must be auth (see shared-schema/protocol.md).
            var first = await ReceiveJsonAsync(webSocket, ct);
            if (first is null || GetType_(first) != "auth")
            {
                await CloseAsync(webSocket, "expected auth message first");
                return;
            }

            authedToken = HandleAuth(first, out var response);
            await SendJsonAsync(webSocket, response, ct);

            if (authedToken is null)
            {
                await CloseAsync(webSocket, "auth failed");
                return;
            }

            // Auth succeeded — immediately push current profile.
            await SendJsonAsync(webSocket, BuildProfileSync(), ct);

            // Main receive loop.
            while (webSocket.State == WebSocketState.Open && !ct.IsCancellationRequested)
            {
                var msg = await ReceiveJsonAsync(webSocket, ct);
                if (msg is null) break;

                switch (GetType_(msg))
                {
                    case "button_press":
                        await HandleButtonPress(webSocket, msg, ct);
                        break;
                    default:
                        // Milestone 2+ message types (profile_edit, etc.) — ignore for now.
                        break;
                }
            }
        }
        catch (WebSocketException)
        {
            // Client disconnected abruptly — normal, nothing to do.
        }
        finally
        {
            if (webSocket.State == WebSocketState.Open)
            {
                try { await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, null, CancellationToken.None); }
                catch { /* best effort */ }
            }
        }
    }

    private string? HandleAuth(JsonElement authMsg, out object response)
    {
        if (authMsg.TryGetProperty("token", out var tokenEl))
        {
            var token = tokenEl.GetString() ?? "";
            if (_pairing.ValidateToken(token))
            {
                response = new { type = "auth_ok", token, hostName = Environment.MachineName };
                return token;
            }
            response = new { type = "auth_failed", reason = "invalid_token" };
            return null;
        }

        if (authMsg.TryGetProperty("pin", out var pinEl))
        {
            var pin = pinEl.GetString() ?? "";
            if (_pairing.ValidatePin(pin))
            {
                var newToken = _pairing.IssueToken();
                response = new { type = "auth_ok", token = newToken, hostName = Environment.MachineName };
                return newToken;
            }
            response = new { type = "auth_failed", reason = "invalid_pin" };
            return null;
        }

        response = new { type = "auth_failed", reason = "no_pin_or_token_provided" };
        return null;
    }

    private async Task HandleButtonPress(WebSocket webSocket, JsonElement msg, CancellationToken ct)
    {
        var buttonId = msg.TryGetProperty("buttonId", out var idEl) ? idEl.GetString() : null;
        var button = _profileStore.Current.Buttons.FirstOrDefault(b => b.ButtonId == buttonId);

        if (button is null)
        {
            await SendJsonAsync(webSocket, new { type = "ack", buttonId, status = "error", message = "unknown buttonId" }, ct);
            return;
        }

        var (success, error) = _actionExecutor.Execute(button.Action);
        await SendJsonAsync(webSocket, success
            ? new { type = "ack", buttonId, status = "ok" }
            : new { type = "ack", buttonId, status = "error", message = error }, ct);
    }

    private object BuildProfileSync() => new { type = "profile_sync", profile = _profileStore.Current };

    private static string GetType_(JsonElement el) =>
        el.TryGetProperty("type", out var t) ? (t.GetString() ?? "") : "";

    // ---- WebSocket framing helpers ----

    private static async Task<JsonElement?> ReceiveJsonAsync(WebSocket ws, CancellationToken ct)
    {
        var buffer = new byte[8192];
        using var ms = new MemoryStream();
        WebSocketReceiveResult result;
        do
        {
            result = await ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
            if (result.MessageType == WebSocketMessageType.Close) return null;
            ms.Write(buffer, 0, result.Count);
        } while (!result.EndOfMessage);

        if (ms.Length == 0) return null;
        ms.Position = 0;
        using var doc = JsonDocument.Parse(ms);
        return doc.RootElement.Clone();
    }

    private static async Task SendJsonAsync(WebSocket ws, object payload, CancellationToken ct)
    {
        var json = JsonSerializer.Serialize(payload);
        var bytes = Encoding.UTF8.GetBytes(json);
        await ws.SendAsync(new ArraySegment<byte>(bytes), WebSocketMessageType.Text, true, ct);
    }

    private static async Task CloseAsync(WebSocket ws, string reason)
    {
        try { await ws.CloseAsync(WebSocketCloseStatus.PolicyViolation, reason, CancellationToken.None); }
        catch { /* best effort */ }
    }

    // ---- Manual HTTP Upgrade handshake (see class doc comment for why) ----

    private static async Task<WebSocket> PerformHandshakeAsync(NetworkStream stream, CancellationToken ct)
    {
        var requestText = await ReadHttpHeadersAsync(stream, ct);
        var key = ExtractHeader(requestText, "Sec-WebSocket-Key")
                  ?? throw new InvalidOperationException("missing Sec-WebSocket-Key");

        var acceptKey = Convert.ToBase64String(
            SHA1.HashData(Encoding.UTF8.GetBytes(key + WebSocketMagicGuid)));

        var responseText =
            "HTTP/1.1 101 Switching Protocols\r\n" +
            "Upgrade: websocket\r\n" +
            "Connection: Upgrade\r\n" +
            $"Sec-WebSocket-Accept: {acceptKey}\r\n\r\n";

        var responseBytes = Encoding.ASCII.GetBytes(responseText);
        await stream.WriteAsync(responseBytes, ct);

        return WebSocket.CreateFromStream(stream, isServer: true, subProtocol: null, keepAliveInterval: TimeSpan.FromSeconds(30));
    }

    private static async Task<string> ReadHttpHeadersAsync(NetworkStream stream, CancellationToken ct)
    {
        var buffer = new List<byte>();
        var single = new byte[1];
        // Read byte-by-byte until we see the blank line ending HTTP headers ("\r\n\r\n").
        // Fine for a handshake (small, one-time) — not used for the actual message loop.
        while (true)
        {
            int n = await stream.ReadAsync(single.AsMemory(0, 1), ct);
            if (n == 0) break;
            buffer.Add(single[0]);
            if (buffer.Count >= 4 &&
                buffer[^4] == '\r' && buffer[^3] == '\n' && buffer[^2] == '\r' && buffer[^1] == '\n')
                break;
        }
        return Encoding.ASCII.GetString(buffer.ToArray());
    }

    private static string? ExtractHeader(string headers, string name)
    {
        foreach (var line in headers.Split("\r\n"))
        {
            var idx = line.IndexOf(':');
            if (idx <= 0) continue;
            if (string.Equals(line[..idx].Trim(), name, StringComparison.OrdinalIgnoreCase))
                return line[(idx + 1)..].Trim();
        }
        return null;
    }

    private static string DetectLocalIpAddress()
    {
        try
        {
            using var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            // Doesn't actually send anything — just asks the OS which local interface would be
            // used to reach an external address, which is a reliable way to find the "real" LAN IP.
            socket.Connect("8.8.8.8", 65530);
            return (socket.LocalEndPoint as IPEndPoint)?.Address.ToString() ?? "unknown";
        }
        catch
        {
            return "unknown";
        }
    }
}
