using System.Diagnostics;
using System.Runtime.InteropServices;

namespace HostApp.Actions;

public class ActionExecutor
{
    public (bool Success, string? Error) Execute(ProfileStore.ActionModel action)
    {
        try
        {
            switch (action.Type)
            {
                case "hotkey":
                    return ExecuteHotkey(action.Keys);
                case "launch_app":
                    return ExecuteLaunchApp(action.Path);
                default:
                    return (false, $"Unknown action type '{action.Type}' (Milestone 2+ action, not implemented yet)");
            }
        }
        catch (Exception ex)
        {
            return (false, ex.Message);
        }
    }

    private (bool, string?) ExecuteHotkey(List<string>? keyNames)
    {
        if (keyNames is null || keyNames.Count == 0)
            return (false, "hotkey action has no keys");

        var vks = new List<ushort>();
        foreach (var name in keyNames)
        {
            if (!VirtualKey.TryGetCode(name, out var vk))
                return (false, $"Unknown key name '{name}'");
            vks.Add(vk);
        }

        // Press all keys down in order, then release in reverse order (standard combo behavior).
        var inputs = new List<INPUT>();
        foreach (var vk in vks)
            inputs.Add(KeyInput(vk, keyUp: false));
        for (int i = vks.Count - 1; i >= 0; i--)
            inputs.Add(KeyInput(vks[i], keyUp: true));

        var arr = inputs.ToArray();
        var sent = SendInput((uint)arr.Length, arr, Marshal.SizeOf(typeof(INPUT)));
        if (sent != arr.Length)
            return (false, $"SendInput only sent {sent}/{arr.Length} inputs");

        return (true, null);
    }

    private (bool, string?) ExecuteLaunchApp(string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return (false, "launch_app action has no path");

        Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        return (true, null);
    }

    private static INPUT KeyInput(ushort vk, bool keyUp) => new()
    {
        type = INPUT_KEYBOARD,
        U = new InputUnion
        {
            ki = new KEYBDINPUT
            {
                wVk = vk,
                wScan = 0,
                dwFlags = keyUp ? KEYEVENTF_KEYUP : 0,
                time = 0,
                dwExtraInfo = IntPtr.Zero
            }
        }
    };

    // ---- P/Invoke boilerplate for SendInput ----

    private const int INPUT_KEYBOARD = 1;
    private const uint KEYEVENTF_KEYUP = 0x0002;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public int type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }
}
