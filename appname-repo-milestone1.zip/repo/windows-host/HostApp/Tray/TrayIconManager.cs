using System.Drawing;
using System.Windows.Forms;

namespace HostApp.Tray;

/// <summary>
/// WPF has no native tray icon API, so this uses System.Windows.Forms.NotifyIcon
/// (requires UseWindowsForms=true in the csproj, already set).
/// </summary>
public sealed class TrayIconManager : IDisposable
{
    private readonly Action _onShowPairingInfo;
    private readonly Action _onExit;
    private NotifyIcon? _notifyIcon;

    public TrayIconManager(Action onShowPairingInfo, Action onExit)
    {
        _onShowPairingInfo = onShowPairingInfo;
        _onExit = onExit;
    }

    public void Initialize()
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("Show Pairing Info", null, (_, _) => _onShowPairingInfo());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => _onExit());

        _notifyIcon = new NotifyIcon
        {
            // TODO: replace with a real app icon (Assets/app.ico) once you have one.
            Icon = SystemIcons.Application,
            Visible = true,
            Text = "HostApp — running",
            ContextMenuStrip = menu
        };

        _notifyIcon.DoubleClick += (_, _) => _onShowPairingInfo();
    }

    public void Dispose()
    {
        if (_notifyIcon is not null)
        {
            _notifyIcon.Visible = false;
            _notifyIcon.Dispose();
        }
    }
}
