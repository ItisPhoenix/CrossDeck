using System.Windows;
using HostApp.Actions;
using HostApp.ProfileStore;
using HostApp.Server;
using HostApp.Tray;

namespace HostApp;

public partial class App : Application
{
    // Held as fields so they aren't garbage collected and so tray menu handlers can reach them.
    private WebSocketServer? _server;
    private TrayIconManager? _tray;
    private PairingManager? _pairing;
    private ProfileStoreService? _profileStore;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        _profileStore = new ProfileStoreService();
        _profileStore.LoadOrCreateDefault();

        var actionExecutor = new ActionExecutor();

        _pairing = new PairingManager();
        _pairing.GenerateNewPin();

        _server = new WebSocketServer(port: 7890, pairing: _pairing, profileStore: _profileStore, actionExecutor: actionExecutor);
        _server.Start();

        _tray = new TrayIconManager(
            onShowPairingInfo: ShowPairingWindow,
            onExit: () =>
            {
                _server?.Stop();
                Shutdown();
            });
        _tray.Initialize();

        // Show pairing info immediately on first launch so it's not hidden behind a tray click.
        ShowPairingWindow();
    }

    private void ShowPairingWindow()
    {
        if (_pairing is null || _server is null) return;

        var window = new PairingWindow(_pairing.CurrentPin, _server.LocalIpAddress, _server.Port);
        window.Show();
        window.Activate();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _server?.Stop();
        _tray?.Dispose();
        base.OnExit(e);
    }
}
