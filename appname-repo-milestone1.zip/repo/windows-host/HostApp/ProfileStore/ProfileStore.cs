using System.IO;
using System.Text.Json;

namespace HostApp.ProfileStore;

public class ProfileStoreService
{
    private readonly string _filePath;
    private readonly JsonSerializerOptions _jsonOptions = new() { WriteIndented = true };

    public Profile Current { get; private set; } = new();

    public event Action<Profile>? ProfileChanged;

    public ProfileStoreService()
    {
        var appDataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "HostApp");
        Directory.CreateDirectory(appDataDir);
        _filePath = Path.Combine(appDataDir, "profile.json");
    }

    public void LoadOrCreateDefault()
    {
        if (File.Exists(_filePath))
        {
            var json = File.ReadAllText(_filePath);
            var loaded = JsonSerializer.Deserialize<Profile>(json, _jsonOptions);
            if (loaded is not null)
            {
                Current = loaded;
                return;
            }
        }

        Current = CreateSampleProfile();
        Save();
    }

    public void Save()
    {
        var json = JsonSerializer.Serialize(Current, _jsonOptions);
        File.WriteAllText(_filePath, json);
    }

    /// <summary>
    /// Milestone 2 will add profile_edit handling here (mutate Current, Save(), then
    /// raise ProfileChanged so the WebSocket server broadcasts profile_sync to all clients).
    /// </summary>
    private void NotifyChanged() => ProfileChanged?.Invoke(Current);

    private static Profile CreateSampleProfile() => new()
    {
        ProfileId = "p_default",
        Name = "Default",
        Buttons = new List<ButtonModel>
        {
            new()
            {
                ButtonId = "b_001",
                Position = new Position { Row = 0, Col = 0 },
                Label = "Mute",
                Action = new ActionModel { Type = "hotkey", Keys = new List<string> { "VolumeMute" } }
            },
            new()
            {
                ButtonId = "b_002",
                Position = new Position { Row = 0, Col = 1 },
                Label = "Notepad",
                Action = new ActionModel { Type = "launch_app", Path = "notepad.exe" }
            },
            new()
            {
                ButtonId = "b_003",
                Position = new Position { Row = 0, Col = 2 },
                Label = "Volume Up",
                Action = new ActionModel { Type = "hotkey", Keys = new List<string> { "VolumeUp" } }
            }
        }
    };
}
