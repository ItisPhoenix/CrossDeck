package com.appname.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.appname.client.connection.ConnectionManager
import com.appname.client.connection.ConnectionState
import com.appname.client.ui.DeckGridScreen
import com.appname.client.ui.PairingScreen

class MainActivity : ComponentActivity() {

    private lateinit var connectionManager: ConnectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        connectionManager = ConnectionManager(applicationContext)
        // If we've paired before, try to reconnect silently with the saved token.
        // If this returns false (no saved pairing), the PairingScreen shows immediately.
        connectionManager.reconnectWithSavedToken()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val state by connectionManager.connectionState.collectAsState()
                    val profile by connectionManager.currentProfile.collectAsState()
                    val error by connectionManager.lastError.collectAsState()

                    when {
                        state == ConnectionState.Connected && profile != null -> {
                            DeckGridScreen(
                                profile = profile!!,
                                onButtonTap = { button ->
                                    connectionManager.sendButtonPress(button.buttonId)
                                }
                            )
                        }
                        state == ConnectionState.Connecting -> {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        }
                        else -> {
                            // Disconnected, AuthFailed, or Error — all fall back to manual pairing.
                            PairingScreen(
                                connecting = false,
                                errorMessage = error,
                                onConnect = { ip, port, pin ->
                                    connectionManager.connectWithPin(ip, port, pin)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        connectionManager.disconnect()
        super.onDestroy()
    }
}
