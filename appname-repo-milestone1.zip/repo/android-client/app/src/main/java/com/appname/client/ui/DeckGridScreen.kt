package com.appname.client.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.appname.client.model.ButtonModel
import com.appname.client.model.Profile

/**
 * Dynamic auto-fit grid (architecture spec decision #11): column count adapts to screen width
 * rather than a fixed layout. Buttons keep their logical (row, col) position — see
 * "Grid Position Semantics" in the architecture spec — this just controls how many fit per row
 * visually. Sorting by (row, col) here approximates a reasonable reading order until an actual
 * reflow-aware layout is built in Milestone 2.
 */
@Composable
fun DeckGridScreen(
    profile: Profile,
    onButtonTap: (ButtonModel) -> Unit
) {
    val sortedButtons = profile.buttons.sortedWith(compareBy({ it.position.row }, { it.position.col }))

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            profile.name,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(16.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 88.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(sortedButtons, key = { it.buttonId }) { button ->
                DeckButton(button = button, onTap = { onButtonTap(button) })
            }
        }
    }
}

@Composable
private fun DeckButton(button: ButtonModel, onTap: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier
            .aspectRatio(1f)
            .clickable { onTap() }
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            // Milestone 3: render button.icon here (custom/built-in icon pack + asset endpoint).
            // Label-only for Milestone 1.
            Text(
                text = button.label,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}
