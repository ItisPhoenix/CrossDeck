package com.appname.client.connection

import android.content.Context
import com.appname.client.model.Profile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

enum class ConnectionState { Disconnected, Connecting, Connected, AuthFailed, Error }

/**
 * Owns the WebSocket connection to the Windows Host. See shared-schema/protocol.md for the
 * exact message formats this implements (Milestone 1 subset: auth, profile_sync, button_press,
 * ack).
 */
class ConnectionManager(context: Context) {

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS) // keeps the connection alive over WiFi power-save
        .build()

    private val json = Json { ignoreUnknownKeys = true }
    private var webSocket: WebSocket? = null
    private val prefs = context.getSharedPreferences("appname_pairing", Context.MODE_PRIVATE)

    private val _connectionState = MutableStateFlow(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _currentProfile = MutableStateFlow<Profile?>(null)
    val currentProfile: StateFlow<Profile?> = _currentProfile.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    fun connectWithPin(ip: String, port: Int, pin: String) {
        savePairing(ip, port)
        openSocket(ip, port) { ws -> sendAuth(ws, pin = pin) }
    }

    /** Returns false if there's no saved pairing to reconnect to. */
    fun reconnectWithSavedToken(): Boolean {
        val ip = prefs.getString(KEY_IP, null) ?: return false
        val port = prefs.getInt(KEY_PORT, -1)
        val token = prefs.getString(KEY_TOKEN, null) ?: return false
        if (port <= 0) return false
        openSocket(ip, port) { ws -> sendAuth(ws, token = token) }
        return true
    }

    fun sendButtonPress(buttonId: String, pressType: String = "short") {
        val obj = buildJsonObject {
            put("type", "button_press")
            put("buttonId", buttonId)
            put("pressType", pressType)
        }
        webSocket?.send(obj.toString())
    }

    fun disconnect() {
        webSocket?.close(1000, "user disconnect")
        webSocket = null
        _connectionState.value = ConnectionState.Disconnected
    }

    private fun openSocket(ip: String, port: Int, onOpenSendAuth: (WebSocket) -> Unit) {
        _connectionState.value = ConnectionState.Connecting
        val request = Request.Builder().url("ws://$ip:$port/ws").build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) = onOpenSendAuth(ws)

            override fun onMessage(ws: WebSocket, text: String) = handleMessage(text)

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                _connectionState.value = ConnectionState.Error
                _lastError.value = t.message
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                _connectionState.value = ConnectionState.Disconnected
            }
        })
    }

    private fun sendAuth(ws: WebSocket, pin: String? = null, token: String? = null) {
        val obj = buildJsonObject {
            put("type", "auth")
            pin?.let { put("pin", it) }
            token?.let { put("token", it) }
        }
        ws.send(obj.toString())
    }

    private fun handleMessage(text: String) {
        val obj = json.parseToJsonElement(text).jsonObject
        when (obj["type"]?.jsonPrimitive?.content) {
            "auth_ok" -> {
                obj["token"]?.jsonPrimitive?.content?.let { saveToken(it) }
                _connectionState.value = ConnectionState.Connected
            }
            "auth_failed" -> {
                _connectionState.value = ConnectionState.AuthFailed
                _lastError.value = obj["reason"]?.jsonPrimitive?.content
            }
            "profile_sync" -> {
                obj["profile"]?.let {
                    _currentProfile.value = json.decodeFromJsonElement(it)
                }
            }
            "ack" -> {
                if (obj["status"]?.jsonPrimitive?.content == "error") {
                    _lastError.value = obj["message"]?.jsonPrimitive?.content
                }
            }
            // Milestone 2+ message types ignored for now.
        }
    }

    private fun savePairing(ip: String, port: Int) {
        prefs.edit().putString(KEY_IP, ip).putInt(KEY_PORT, port).apply()
    }

    private fun saveToken(token: String) {
        prefs.edit().putString(KEY_TOKEN, token).apply()
    }

    companion object {
        private const val KEY_IP = "ip"
        private const val KEY_PORT = "port"
        private const val KEY_TOKEN = "token"
    }
}
